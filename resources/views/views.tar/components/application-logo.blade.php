<img src="{{ asset('images/download-removebg-preview.png') }}" alt="Sage Experience Logo" class="w-48 h-auto" {{ $attributes }} />
