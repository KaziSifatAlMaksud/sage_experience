<x-filament-panels::page>
    <div style="background: #ff0; color: #000; padding: 8px; text-align: center; font-weight: bold;">TEST_MARKER_ABC123</div>
    <x-filament::section class="bg-[#f8faf7] border-gray-200">
        <div class="mb-8 flex flex-col gap-4">
            <div class="bg-white rounded-lg p-6 shadow border border-gray-200">
                <h3 class="text-xl font-medium mb-4 text-sage-700">Evaluate My Latest Performance</h3>
                <div class="flex flex-col md:flex-row gap-4">
                    <a href="{{ route('filament.admin.pages.skill-practice') }}" class="inline-flex items-center justify-center px-5 py-3 border border-transparent rounded-md text-sm font-medium text-white bg-sage-600 hover:bg-sage-700 transition">
                        <x-heroicon-o-academic-cap class="h-5 w-5 mr-2" />
                        Evaluate My Latest Performance
                    </a>
                    <a href="{{ route('filament.admin.pages.peer-evaluation') }}" class="inline-flex items-center justify-center px-5 py-3 border border-gray-300 bg-white rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 transition">
                        <x-heroicon-o-user-group class="h-5 w-5 mr-2" />
                        Evaluate Team Member Performance
                    </a>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div class="rounded-lg bg-white p-4 shadow border border-gray-200">
                <div class="flex items-center">
                    <div class="rounded-full bg-primary-900 p-2.5 mr-5">
                        <x-heroicon-o-chat-bubble-left-right class="h-6 w-6 text-primary-400" />
                    </div>
                    <div>
                        <p class="text-lg font-bold text-gray-800">{{ $totalFeedback }}</p>
                        <p class="text-sm text-gray-500">Total Feedback</p>
                    </div>
                </div>
            </div>

            <div class="rounded-lg bg-white p-4 shadow border border-gray-200">
                <div class="flex items-center">
                    <div class="rounded-full bg-success-900 p-2.5 mr-5">
                        <x-heroicon-o-check-circle class="h-6 w-6 text-success-400" />
                    </div>
                    <div>
                        <p class="text-lg font-bold text-gray-800">{{ $positiveFeedback }}</p>
                        <p class="text-sm text-gray-500">Positive Feedback</p>
                    </div>
                </div>
            </div>

            <div class="rounded-lg bg-white p-4 shadow border border-gray-200">
                <div class="flex items-center">
                    <div class="rounded-full bg-warning-900 p-2.5 mr-5">
                        <x-heroicon-o-arrow-trending-up class="h-6 w-6 text-warning-400" />
                    </div>
                    <div>
                        <p class="text-lg font-bold text-gray-800">{{ $improvementFeedback }}</p>
                        <p class="text-sm text-gray-500">Areas for Improvement</p>
                    </div>
                </div>
            </div>
        </div>

        Skills I've Demonstrated
        <div class="mb-8">
            <h3 class="text-lg font-medium mb-4 text-gray-800">Recent Skills Demonstrated</h3>

            @if($userSkillPractices->isEmpty())
                <div class="bg-white rounded-lg p-6 shadow border border-gray-200 text-center">
                    <div class="text-gray-400 mb-2">
                        <x-heroicon-o-academic-cap class="inline-block w-12 h-12" />
                    </div>
                    <h3 class="text-lg font-medium text-gray-800">No skills recorded yet</h3>
                    <p class="mt-1 text-sm text-gray-500">Start by evaluating your performance to track skills you've demonstrated.</p>
                </div>
            @else
                <div class="space-y-4">
                    @php
                        // Group demonstrated practices by area, then by skill
                        $areaGroups = $userSkillPractices->groupBy(function($item) { return $item->skill->skillArea->id; });

                        // Sort skills by frequency within each area
                        foreach ($areaGroups as $areaId => $practicesByArea) {
                            $skillsInArea = $practicesByArea->groupBy('skill_id');
                            $sortedSkills = $skillsInArea->sortByDesc(function($group) {
                                return $group->count();
                            });
                            $areaGroups[$areaId] = $practicesByArea;
                        }
                    @endphp

                    @foreach($areaGroups as $areaId => $practicesByArea)
                        @php
                            $area = $practicesByArea->first()->skill->skillArea;
                            $color = $colors[$area->id] ?? '#888888';
                            $skillsInArea = $practicesByArea->groupBy('skill_id');

                            // Sort skills by frequency (most frequent first)
                            $sortedSkills = $skillsInArea->sortByDesc(function($group) {
                                return $group->count();
                            });
                        @endphp
                        <div class="border rounded-lg overflow-hidden bg-white shadow" style="border-left: 4px solid {{ $color }};">
                            <div class="flex items-center p-4 bg-white">
                                <div class="font-bold text-lg text-gray-900">{{ $area->name }}</div>
                            </div>
                            <div class="pl-8 pr-4 py-3 bg-gray-50">
                                @foreach($sortedSkills as $skillId => $practicesBySkill)
                                    @php
                                        $skill = $practicesBySkill->first()->skill;
                                        $count = $practicesBySkill->count();
                                        $fontSize = $count >= 3 ? 'text-3xl' : ($count == 2 ? 'text-2xl' : 'text-base');
                                    @endphp
                                    <div class="mb-2">
                                        <div class="flex items-center justify-between">
                                            <div class="font-medium text-base text-gray-800">{{ $area->name }}: {{ $skill->name }}</div>
                                            @if($count > 1)
                                                <span class="font-bold text-sage-600 {{ $fontSize }}">{{ $count }}×</span>
                                            @endif
                                        </div>
                                        <ul class="space-y-2 mt-1 pl-8">
                                            @foreach($practicesBySkill as $practice)
                                                <li class="p-2 bg-gray-100 rounded text-sm text-gray-600">{{ $practice->practice->description }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    @endforeach
                </div>
            @endif
        </div>

        <!-- Skills I Want to Improve -->
        <div class="mb-8">
            <h3 class="text-lg font-medium mb-4 text-gray-800">Skills I Want to Improve</h3>

            @if($userFuturePractices->isEmpty())
                <div class="bg-white rounded-lg p-6 shadow border border-gray-200 text-center">
                    <div class="text-gray-400 mb-2">
                        <x-heroicon-o-arrow-trending-up class="inline-block w-12 h-12" />
                    </div>
                    <h3 class="text-lg font-medium text-gray-800">No improvement areas recorded yet</h3>
                </div>
            @else
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    @php
                        // Sort skills by improvement frequency minus demonstration frequency
                        $improvementSkills = $userFuturePractices->groupBy('skill_id');
                        $sortedImprovements = $improvementSkills->sortByDesc(function($group) use ($skillFrequency) {
                            $skillId = $group->first()->skill_id;
                            $improvementCount = $group->count();
                            $demonstratedCount = $skillFrequency[$skillId] ?? 0;
                            return $improvementCount - $demonstratedCount;
                        });
                    @endphp

                    @foreach($sortedImprovements as $skillId => $practices)
                        @php
                            $skill = $practices->first()->skill;
                            $area = $skill->skillArea;
                            $count = $practices->count();
                            $color = $colors[$area->id] ?? '#888888';
                            $demoCount = $skillFrequency[$skillId] ?? 0;
                        @endphp

                        <div class="bg-white rounded-lg p-5 shadow border border-gray-200" style="border-left-width: 4px; border-left-color: {{ $color }};">
                            <div class="flex items-center justify-between mb-2">
                                <h4 class="font-medium text-gray-800">
                                    <span>{{ $area->name }}: {{ $skill->name }}</span>
                                </h4>
                                @if($count > 1)
                                    <span class="font-bold text-amber-600">{{ $count }}×</span>
                                @endif
                            </div>

                            <div class="space-y-2 mt-3">
                                @foreach($practices as $practice)
                                    <div class="p-2 bg-gray-50 rounded text-sm text-gray-600" style="margin-left:8px;">
                                        {{ $practice->practice->description }}
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    @endforeach
                </div>
            @endif
        </div>

       
    </x-filament::section>
</x-filament-panels::page>
