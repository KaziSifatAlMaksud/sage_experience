<x-filament::page>
    {{-- Any dashboard content goes here if needed --}}

    @if (!empty($actions))
        <div class="mt-10 flex justify-center">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 w-full max-w-5xl">
                @foreach ($actions as $action)
                    {{ $action }}
                @endforeach
            </div>
        </div>
    @endif
</x-filament::page>
